#include <stdio.h>

int main()
{
    //Write logic to check the given number is prime or not
}